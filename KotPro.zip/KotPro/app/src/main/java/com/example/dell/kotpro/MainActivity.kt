package com.example.dell.kotpro

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.android.volley.AuthFailureError
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.example.dell.kotpro.network.EndPoints
import com.example.dell.kotpro.network.VolleySingleton
import org.json.JSONException
import org.json.JSONObject


private val TAG = "PermissionDemo"
class MainActivity : AppCompatActivity() {
    private lateinit var myReceiver: BroadcastReceiver
    lateinit var  context : Context;

    private val requestReceiveSms=2
    var receiver: BroadcastReceiver? = null
    val SMS_BUNDLE = "pdus"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        context= this;
        setupPermissions();
        val txt_message : TextView = findViewById(R.id.txt_message) as TextView
        setupPermissions2()
        LocalBroadcastManager.getInstance(this).registerReceiver(broadCastReceiver, IntentFilter(Context.TELEPHONY_SERVICE))


        //adding a click listener to button
      val btn_registration : Button =   findViewById(R.id.btn_registration) as Button
        btn_registration.setOnClickListener {
            Toast.makeText(applicationContext, "call method", Toast.LENGTH_LONG).show()
            doReg()
        }

    }

    private fun setupPermissions() {
       if (ActivityCompat.checkSelfPermission(this,Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED){

           ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECEIVE_SMS),requestReceiveSms)
       }
    }


    private fun setupPermissions2() {
       if (ActivityCompat.checkSelfPermission(this,Manifest.permission.CHANGE_NETWORK_STATE)!=PackageManager.PERMISSION_GRANTED){

           ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CHANGE_NETWORK_STATE),requestReceiveSms)
       }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        Log.e("ffdfd","")
    }

    override fun onStart() {
        super.onStart()

    }

    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadCastReceiver)
    }

    val broadCastReceiver = object : BroadcastReceiver() {
        override fun onReceive(contxt: Context?, intent: Intent?) {
            Log.e(">>>>>>>><<<<<<<??>>>","");

            val b = intent!!.getExtras()
            val message = b.getString("message")

            Log.e("newmesage", "" + message!!)
            when (intent?.action) {

            }
        }
    }


    //adding a new record to database
    private fun doReg() {
        //getting the record values
        val name = ""
        val genre = ""

        //creating volley string request
        val stringRequest = object : StringRequest(Request.Method.POST, EndPoints.URL_REGISTRATION,
                Response.Listener<String> { response ->
                    try {
                        val obj = JSONObject(response)
                      //  Toast.makeText(applicationContext, obj.getString("message"), Toast.LENGTH_LONG).show()
                        Log.e("obj>>>>",obj.toString()+"")
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                object : Response.ErrorListener {
                    override fun onErrorResponse(volleyError: VolleyError) {
                       // Toast.makeText(applicationContext, volleyError.message, Toast.LENGTH_LONG).show()
                        Log.e("obj>>>>",volleyError.message+"")
                    }
                }) {
            @Throws(AuthFailureError::class)
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params.put("name", "rashedzzaman")
                params.put("email", "rashedghj@gmail.com")
                params.put("username", "rasheduzzaman")
                params.put("password", "123456")
                params.put("phone", "01711950066")
                Log.e("params>>",params.toString()+"");
                return params
            }
        }
        Log.e("VolleySingleton>>","<>"+"");
        //adding request to queue
        VolleySingleton.instance?.addToRequestQueue(stringRequest)
    }
}



