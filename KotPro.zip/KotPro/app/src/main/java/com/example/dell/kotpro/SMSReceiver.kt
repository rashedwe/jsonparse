package com.example.dell.kotpro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsMessage
import android.util.Log
import android.widget.Toast
import java.util.*
import androidx.core.app.NotificationCompat.getExtras
import android.os.Bundle
import android.util.Config


const val SMS_BUNDLE = "pdus"

class SMSReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {

        val intentExtras = intent.extras
        if (intentExtras!=null){
            val sms = intentExtras.get("pdus") as Array<Any>
            for (i in sms.indices){
                    val formate = intentExtras.getString("format")
                var smsMessage = if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
                    SmsMessage.createFromPdu(sms[i] as ByteArray,formate)

                }else{
                    SmsMessage.createFromPdu(sms[i] as ByteArray)
                }

                val phoneNumber = smsMessage.originatingAddress
                val messageText = smsMessage.messageBody.toString()

                Log.e(">>>>>>>>>>>>>>",phoneNumber+messageText+"");
              //Toast.makeText(context,"message text: $messageText",Toast.LENGTH_SHORT).show()

                val extras = intent.extras
                val i = Intent("broadCastName")
                // Data you need to pass to activity
                i.putExtra("message", extras.getString(messageText))

                context.sendBroadcast(i)

            }
        }
    }
}