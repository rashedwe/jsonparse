package com.example.dell.kotpro.network

object EndPoints {
    private val URL_ROOT = "http://192.168."
    val URL_REGISTRATION = "http://localhost:3005/api/v1/reg1"
    val URL_REGISTRATION_OTP = "http://localhost:3005/api/v1/reg2"

}