package com.example.dell.kotpro;

import static org.junit.Assert.*;

public class SMSReceiverTest {

}